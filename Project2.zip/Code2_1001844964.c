// Aryan Mainkar
// 1001844964
// Coding Assignment 2
// CSE 3318-001

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void insertionSort(int Arr[], int Elements)
{
    int i, key, j;
    for (i = 1; i < Elements; i++)
    {
        key = Arr[i];
        j = i - 1;

        while (j >= 0 && Arr[j] > key)
        {
            Arr[j + 1] = Arr[j];
            j = j - 1;
        }
        Arr[j + 1] = key;
    }
}

int readfileintoarray(int argc, char *argv[], int **Arr)
{

    FILE *FH = NULL;
    char buffer[100];
    int count = 0;
    int i = 0;
    
    FH = fopen(argv[1], "r");

    while (fgets(buffer, sizeof(buffer), FH))
    {
        count++;
    }
    
    fseek(FH, 0, SEEK_SET);
    *Arr = malloc((count+1)*sizeof(int));
    
    while (fgets(buffer, sizeof(buffer), FH))
    {
        (*Arr)[i] = atoi(buffer); 
        i++;
    }
    
    return count;
    free(*Arr);
    fclose(FH);  
}

void PrintArray(int Arr[], int SizeAp)
{
    int i;
    for (i = 0; i < SizeAp; i++)
    {
        printf("%d\n", Arr[i]);
    }
    printf("\n\n");
}

int main(int argc, char *argv[])
{
    int *Arr = NULL;
    int Elements;
    clock_t start,end;

    Elements = readfileintoarray(argc, argv, &Arr);
    #ifdef PRINTARRAY
      PrintArray(Arr,Elements);
    #endif
    
    start = clock();
    insertionSort(Arr,Elements);
    end = clock();
    
    #ifdef PRINTARRAY
       PrintArray(Arr, Elements);
       printf("Processed %d records\n",Elements);
    #endif
    printf("\nInsertion Sort = %ld Tics\n",end-start);
    printf("\n");
    return 0;   
}
 

