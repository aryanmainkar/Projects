/*
 * Aryan Mainkar 1001844964
 */
package code1_1001844964;

/**
 *
 * @author Aryan
 */
import java.util.Scanner;


public class Code1_1001844964
{

    enum ACTION 
    {
        DISPENSECHANGE, INSUFFICIENTCHANGE, INSUFFICIENTFUNDS, EXACTPAYMENT, OK
    }

    public static String displayMoney(int money) 
    {

        String strMoney;
        int moneyQ = money / 100;
        int moneyD = money % 100;
        strMoney = "$" + String.valueOf(moneyQ) + "." + String.valueOf(moneyD);

        return strMoney;
    }

    public static int PencilMenu() 
    {
        int choice = 0;
        Scanner in = new Scanner(System.in);

        do
        {
            System.out.print("\n\nPlease choose from the following options\n\n\n");
            System.out.print(
                "0. No pencils for me today\n1. Purchase pencils\n2. Check inventory levels\n3. Check change level");
            System.out.print("\n\nChoice : ");
            choice = in.nextInt();
            if (choice < 0 || choice > 3)
            {
                System.out.println("Invalid Menu Option");
            }
        }while (choice < 0 || choice > 3);
        return choice;
    }

    public static ACTION buyPencils(int numarr[], int totalcost, int pencilInput, int userpayment,
            String ReturnChange[]) 
    {
        ACTION action = ACTION.OK;
        if (totalcost == userpayment) 
        {
            numarr[0] = numarr[0] - pencilInput;
            numarr[1] = numarr[1] + totalcost;
            action = ACTION.EXACTPAYMENT;
        }

        if (userpayment > numarr[1]) 
        {
            action = ACTION.INSUFFICIENTCHANGE;
        }

        if (userpayment > totalcost && numarr[1] > (userpayment - totalcost)) 
        {
            numarr[0] = numarr[0] - pencilInput;
            ReturnChange[0] = displayMoney(userpayment - totalcost);
            numarr[1] = numarr[1] + totalcost;
            action = ACTION.DISPENSECHANGE;
        }

        if (userpayment < totalcost) 
        {
            action = ACTION.INSUFFICIENTFUNDS;
        }

        return action;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Scanner in = new Scanner(System.in);
        final int pencilprice = 60;
        int inventory = 100;
        int change = 500;
        int pencilInput = 0;
        int totalcost = 0;
        int numarr[] = { 0, 0 };
        int userpayment = 0;
        String Returnchange[] = { " " };
        numarr[0] = inventory;
        numarr[1] = change;

        int choice = -1;
        ACTION action = ACTION.OK;

        System.out.print("\nWelcome to my Pencil Machine\n");

        while (choice != 0) 
        {
            choice = PencilMenu();
            switch (choice) 
            {
                case 1:
                    System.out.printf("A pencil costs %s\n", displayMoney(pencilprice));
                    System.out.printf("How many pencils would you like to purchase? ");
                    pencilInput = in.nextInt();

                    if (numarr[0] == 0) 
                    {
                        System.out.println("\nThe Pencil Dispenser is out of inventory");
                        choice = PencilMenu();
                    }

                    while (numarr[0] <= 0 || pencilInput > numarr[0] || pencilInput <= 0)
                    {
                        System.out.printf("Cannot sell that quantity of pencils. Please reenter quantity ");
                        pencilInput = in.nextInt();
                    }

                    totalcost = (pencilprice * pencilInput);
                    System.out.printf("\n\nYour total is %s\n\n", displayMoney(totalcost));
                    System.out.printf("Enter your payment (in cents) ");
                    userpayment = in.nextInt();

                    action = buyPencils(numarr, totalcost, pencilInput, userpayment, Returnchange);

                    inventory = numarr[0];
                    change = numarr[1];

                    switch (action) 
                    {
                        case DISPENSECHANGE:
                            System.out.printf("Here's your pencils and your change of %s", Returnchange[0]);
                            break;

                        case INSUFFICIENTCHANGE:
                            System.out.println(
                                    "This pencil Dispenser does not have enough change and cannot accept your payment.");
                            break;

                        case INSUFFICIENTFUNDS:
                            System.out.println("You did not enter a sufficient payment. No pencils for you");
                            break;

                        case EXACTPAYMENT:
                            System.out.println("Here's your pencils. Thank you for exact payment");
                            break;

                        default:

                    }

                    break;
                case 2:
                    System.out.printf("The current inventory level is %d", inventory);
                    break;

                case 3:
                    System.out.printf("The current change level is %s", displayMoney(change));
                    break;

                default:
                    break;

            }

        }
    }
}