/*
 * Aryan Mainkar 1001844964
 */
package code6_1001844964;
/**
 *
 * @author Aryan
 */
import javax.swing.JFrame;

public class Code6_1001844964
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Password password = new Password();
        password.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        password.setSize(1280,720);
        password.setVisible(true);     
    }
    
}



