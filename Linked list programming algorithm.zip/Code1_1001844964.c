/* Coding Assignment 1 */
//Aryan Mainkar
//1001844964
//CSE-3318-001

#include <stdlib.h> 
#include <stdio.h> 
#include <string.h>
#include <time.h>

typedef struct node
{
   int number;
   struct node *next_ptr;
}
NODE;

void AddNodeToLL(int Number, NODE **LinkedListHead)
{
   NODE *newnode,*tempptr;
   newnode = malloc(sizeof(NODE));
   newnode->number = Number;
   newnode->next_ptr = NULL;

   if(*LinkedListHead == NULL)
   {
	   *LinkedListHead = newnode;
   }

   else
   {
	   tempptr = *LinkedListHead;
	   
	   while(tempptr->next_ptr != NULL)
	   {
	      tempptr = tempptr->next_ptr;
	   }
	   
	   tempptr->next_ptr = newnode;
   }
	
	
}

void ReadFileIntoLL(int argc,  char *argv[], NODE **LLH)
{

    FILE* FH = NULL;
    char buffer[100];
    int rec = 0;
    int sum = 0;
 
 
    if(argc!=2)
	{
	   printf("File must be provided on command line...exiting\n");
	   exit(0);
   }
    else
   {
      FH = fopen(argv[1],"r");
   }
		
    while(fgets(buffer,sizeof(buffer), FH))
    {
      AddNodeToLL(atoi(buffer),LLH);
	   sum = sum + atoi(buffer);
	   rec++;
    }

    fclose(FH);
    printf("\n%d records were read for a total sum of %d\n",rec,sum);
    	
}


void PrintLL(NODE *LLH) 
{ 
    printf("\n");
  
    int sum = 0;
    int rec = 0;
    
	while(LLH!=NULL)
	{
       printf("%p %d %p\n",LLH,LLH->number,LLH->next_ptr);
	    rec++;
	    sum = sum + LLH->number;
	    LLH = LLH->next_ptr;
	}
    
	printf("\n%d records were read for a total sum of %d\n",rec,sum);
}

void FreeLL(NODE **LLH) 
{ 
   NODE *tempptr;
   int rec = 0;
   int sum = 0;
	
   tempptr = *LLH;
   printf("\n");
	
	
   while(tempptr!=NULL)
   {
      #ifdef PRINT
         printf("Freeing %p %d %p\n",tempptr, tempptr->number, tempptr->next_ptr);
	   #endif
	   *LLH=tempptr->next_ptr;
	   rec++;
	   sum = sum + tempptr->number;
	   free(tempptr);
      tempptr = *LLH;
   }
  
   printf("\n%d nodes were deleted for a total sum of %d\n",rec,sum);
	
}

int main(int argc,char *argv[]) 
{ 
   NODE *LLH = NULL;
   clock_t start;
   clock_t end;
	
 /* capture the clock in a start time */
	
   start = clock();
   ReadFileIntoLL(argc, argv, &LLH);
   end = clock();

 /* capture the clock in an end time */
	
   printf("\n%ld tics to write the file into the linked list\n", end-start);
	
 /* capture the clock in a start time */
	
   #ifdef PRINT
	   start = clock();
	   PrintLL(LLH);
	   end = clock();
   #endif
	
 /* capture the clock in an end time */
   #ifdef PRINT
	   printf("\n%ld tics to print the linked list\n", end-start);
   #endif
 /* capture the clock in a start time */
		
   start = clock();
   FreeLL(&LLH);
   end = clock();
		
 /* capture the clock in an end time */
	
   printf("\n%ld tics to free the linked list\n", end-start);
	
   return 0; 
} 
