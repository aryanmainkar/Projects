% Peak Detection Script#1

clear all; 
close  all;

load '100m.mat'; % read binary Matlab file (*.mat)
                 % data values in variable 'val'- you need to check
                 % variable name in the given .mat file from the workspace


y=val(2,:); % extract ECG magnitude from val, row 1 
%t=val(1,:); % extract time magnitude from val,  column 1

sampling_time =0.003; % time between data points in seconds

t(1:length(y))=((1:length(y))-1)*sampling_time; % create a time array for ECG signal y by multiplying index with sampling rate
  
%t=y*sampling_time; % either of time valuesline 13 or 15)can be used 
                                       
                                      
 n=0; % initialize peak counter
threshold=10;

for i=1:length(y)-2   % start for loop 
   
    
  if (y(i+1)-y(i)>0) &  (y(i+2)-y(i+1) <= 0) & y(i) > threshold % conditional statement to find peaks
                                                                % by comparing consecutive slopes 
                                                                % and setting threshold 
                                                       
    
      n=n+1;        % counter for peak indices
      R(n)=i+1;     % index value of the peak
      TR(n)=t(i+1); % time value of the peak
      
  else
      % add more statements if additional conditions have to be satisfied
  end % end for conditional loop
  
end   % end of for loop


for j=1:n-1
    
    RR(j)=(R(j+1)-R(j))*sampling_time; % calculating time interval between R peaks
    
end

%%%%%%%%%%%%%%%%%Plotting ECG Signal and the RR interval%%%%%%%%%%%%%%

subplot (2, 1, 1);
set(gca,'fontsize', 12);
plot(t,y);
findpeaks(y,1/sampling_time,'MinPeakHeight',5); 
title('ECG Signal');
xlabel ('time(sec)'); ylabel ('ECG magnitude (mV)');


subplot (2, 1, 2);
set(gca,'fontsize', 12);
plot(TR(1:n-1),RR);
title ('RR Interval');
xlabel ('time(sec)'); ylabel ('RR interval (sec)');







