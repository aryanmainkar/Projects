// Aryan Mainkar
// 1001844964
// Coding Assignment 3
// CSE 3318-001

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


void swap(int *SwapA, int *SwapB) 
{  
    int temp = *SwapA; 
    *SwapA = *SwapB; 
    *SwapB = temp; 
}

int partition (int A[], int low, int high) 
{ 
    int i, j = 0;
    
    #if QSM
    
        int middle = (high+low)/2;
        swap(&A[middle], &A[high]);
    
    #elif QSRND
    
        int random = (rand() % (high-low+1)) + low;
        swap(&A[random], &A[high]);
    #endif
    
    int pivot = A[high];
    
    i = (low - 1); 
    
    for (j = low; j < high; j++) 
    { 
        if (A[j] < pivot) 
        { 
            i++; 
            swap(&A[i], &A[j]); 
        } 
    } 
    
    swap(&A[i + 1], &A[high]); 
    return (i + 1); 
}

void QuickSort(int A[], int low, int high) 
{ 
    if (low < high) 
    { 
        int ndx = partition(A, low, high); 
        QuickSort(A, low, ndx - 1); 
        QuickSort(A, ndx + 1, high); 
    } 
}


int readfileintoarray(int argc, char *argv[], int **Arr)
{

    FILE *FH = NULL;
    char buffer[100];
    int count = 0;
    int i = 0;

    FH = fopen(argv[1], "r");
    if(FH==NULL)
    {
        if(argc<2)
        {
            printf("Number of runs not specified on command line...defaulting to 10\n");
            printf("File must be provided on command line...exiting\n");
	        exit(0);    
        }
        printf("Invalid File Name...Exiting\n");
        exit(0);
    }
   
  
      
    while(fgets(buffer, sizeof(buffer), FH))
    {
        count++;
    }
    
    fseek(FH, 0, SEEK_SET); 
    *Arr = malloc((count+1)*sizeof(int));
    
    while(fgets(buffer, sizeof(buffer), FH))
    {
        (*Arr)[i] = atoi(buffer); 
        i++;
    }
    
    fclose(FH);
    return count;    
     
}

void PrintArray(int Arr[], int SizeAp)
{
    int i;
    for(i = 0; i < SizeAp; i++)
    {
        printf("%d\n", Arr[i]);
    }
    printf("\n\n");
}

int main(int argc, char *argv[])
{
    int *Arr = NULL;
    int Elements;
    int loopcounter = 10;
    clock_t start1,end1;
    int i;
   
    if(argc>2)
    {
        loopcounter = atoi(argv[2]);
    }

    for(i = 1;i<=loopcounter;i++)
    {
        Elements = readfileintoarray(argc, argv, &Arr);
        
        #ifdef PRINTARRAY
            PrintArray(Arr,Elements);
        #endif
        
        start1 = clock();
        QuickSort(Arr,0,Elements-1);
        end1 = clock();
        printf("Run %d complete : %ld tics\n",i,end1-start1); 
        
        #ifdef PRINTARRAY
            PrintArray(Arr,Elements);
        #endif
        
        free(Arr);
    }
      
    printf("The average run time for %d runs is %ld\n\n\n\n",loopcounter,(start1+end1)/loopcounter);
    printf("Processed %d records\n",Elements);
    
    return 0; 
}
    
    

